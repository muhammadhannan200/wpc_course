<?php 

class Wpc_Popular_Posts extends WP_Widget
{
    function __construct() {
        parent::__construct('wpc_popular_posts', 'WPC Popular Posts');
    }
    function widget($args, $instance) {
        echo $args['before_widget'];
        echo $args['before_title'] . 'Popular Posts' . $args['after_title'];
        $popular_posts = get_posts([
            'orderby' => 'meta_value_num',
            'meta_key' => 'wpc_post_views',
            'order' => 'desc',
            'numberposts' => (isset($instance['posts_count']) && is_numeric($instance['posts_count']) && $instance['posts_count'] > 0) ? $instance['posts_count'] : 4,
        ]);
    if (isset($instance['alt_content'])) {
            $alt_content = $instance['alt_content'];
        } else {
            $alt_content = 'post_date';
        }
        ?>
        <p>
            <label for="">Widget Title</label>
            <input type="text" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>">
        </p>
        <p>
            <label for="">Posts Count</label>
            <input type="number" name="<?php echo $this->get_field_name('posts_count'); ?>" value="<?php echo $posts_count; ?>" min="1" id="">
        </p>
        <p>
            <label for="">Alt Content</label>
            <select name="<?php echo $this->get_field_name('alt_content') ?>" id="">
                <option value="post_date" <?php echo ($alt_content == 'post_date') ? 'selected' : ''; ?>>Post date</option>
                <option value="post_views" <?php echo ($alt_content == 'post_views') ? 'selected' : ''; ?>>Post views</option>
            </select>
        </p>
        <?php
    }
}
add_action('widgets_init',function(){
    register_widget('Wpc_Popular_posts');
});
