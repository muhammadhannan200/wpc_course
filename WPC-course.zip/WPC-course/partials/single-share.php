<div class="post-sharing">
                    <ul class="list-inline">
                        <li><a target='_blank' href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $args['post_link'];?>" class="fb-button btn btn-primary"><i class="fa fa-facebook"></i> <span class="down-mobile">Share on Facebook</span></a></li>
                        <li><a target='_blank' href="https://www.twitter.com/intent/tweet?url=<?php echo $post_link; ?>" class="tw-button btn btn-primary"><i class="fa fa-twitter"></i> <span class="down-mobile">Tweet on Twitter</span></a></li>
                    </ul>
                </div><!-- end post-sharing -->