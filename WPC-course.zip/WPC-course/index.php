<?php
echo "from index php"?>    